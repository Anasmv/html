var div=document.createElement("div"); 
document.querySelector('.navbar-collapse').appendChild(div);

html = "<div><button onclick=' btn_clk();' class='btn btn-sm btn-primary m-1' >Upload Voter Roll</button>  </div>";
div.innerHTML=html;


var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('http://sahayikendra.com/electionsoft/extension/js.js');


(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
